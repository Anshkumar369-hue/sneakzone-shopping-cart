SNEAKZONE TWO-PAGE CART DEMO

PAGE 1: index.html
- Product/store page with sneaker photos.
- Add to Cart implements the SNEAK-13 demonstration.
- Cart count updates.

PAGE 2: cart.html
- Displays selected products.
- Quantity +/- controls.
- Correct total calculation.
- Remove button implements the SNEAK-14 demonstration.
- Empty-cart state.
- Continue Shopping returns to Page 1.

The cart is stored in browser localStorage so products remain when moving between both pages.

Run:
1. Extract ZIP.
2. Open index.html.
3. Add a sneaker.
4. Click Cart to open cart.html.
